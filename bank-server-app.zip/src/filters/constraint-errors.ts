/* eslint-disable camelcase */

interface IConstraintErrors {
    [constraintKey: string]: string;
}

export const ConstraintErrors: IConstraintErrors = {
    UQ_97672ac88f789774dd47f7c8be3: 'error.unique.email',
};
