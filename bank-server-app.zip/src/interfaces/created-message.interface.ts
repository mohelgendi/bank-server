export interface ICreatedMessage {
  developerAge: number;
  customerCount: number;
}
