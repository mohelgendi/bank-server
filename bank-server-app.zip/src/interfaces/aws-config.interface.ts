export interface IAwsConfig {
  accessKeyId: string;
  secretAccessKey: string;
  bucketName: string;
}
