import { PageOptionsDto } from 'common/dtos';

export class BillsPageOptionsDto extends PageOptionsDto {}
