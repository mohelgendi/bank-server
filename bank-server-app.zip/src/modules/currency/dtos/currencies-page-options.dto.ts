import { PageOptionsDto } from 'common/dtos';

export class CurrenciesPageOptionsDto extends PageOptionsDto {}
