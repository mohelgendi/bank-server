import { PageOptionsDto } from 'common/dtos';

export class TransactionsPageOptionsDto extends PageOptionsDto {}
