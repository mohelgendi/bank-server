import { PageOptionsDto } from 'common/dtos';

export class MessagesPageOptionsDto extends PageOptionsDto {}
