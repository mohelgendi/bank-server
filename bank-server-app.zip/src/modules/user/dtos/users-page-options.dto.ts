import { PageOptionsDto } from 'common/dtos';

export class UsersPageOptionsDto extends PageOptionsDto {}
