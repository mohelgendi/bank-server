export * from './abstract.entity';
