export enum Language {
  AR = 'ar', // Arabıc
  EN = 'en', // Englısh
  TL = 'tl', // Türkısh 
}
