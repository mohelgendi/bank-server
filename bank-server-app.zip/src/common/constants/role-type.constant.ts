export enum RoleType {
  USER = 'USER_ROLE',
  ADMIN = 'ADMIN_ROLE',
  ROOT = 'ROOT_ROLE',
}
